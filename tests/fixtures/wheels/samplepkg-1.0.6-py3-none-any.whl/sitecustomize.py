# harmless fixture
