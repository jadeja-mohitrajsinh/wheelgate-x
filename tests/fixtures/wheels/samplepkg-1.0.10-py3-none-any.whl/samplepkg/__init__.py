# Safe synthetic sample package. Not imported.
